//
//  ViewController.swift
//  test3
//
//  Created by Ibrokhim Mirzakhonov on 2/19/20.
//  Copyright © 2020 PPU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


